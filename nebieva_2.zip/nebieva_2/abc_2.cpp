#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n;
    cout << "Enter the number of numbers (example 3): ";
    cin >> n;

    // Проверка на корректность ввода
    if (n <= 0) {
        cout << "The number of numbers must be positive!" << endl;
        return 1;
    }

    vector<float> numbers(n);

    // Ввод чисел
    cout << "Enter " << n << " floating point numbers (IEEE 754 format) (example 1.5, -2.5, 3.0):" << endl;
    for (int i = 0; i < n; ++i) {
        cin >> numbers[i];
    }

    // Вычисление суммы
    float sum = 0.0f;
    for (int i = 0; i < n; ++i) {
        sum += numbers[i];
    }

    cout << "Sum of the entered numbers (answer 2): " << sum << endl;

    return 0;
}