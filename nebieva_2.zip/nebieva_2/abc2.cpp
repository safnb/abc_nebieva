#include <iostream>
#include <vector>
#include <limits>

using namespace std;

int main() {
    int n;
    cout << "Enter the number of numbers: ";
    cin >> n;

    // Проверка на корректность ввода
    if (n <= 0) {
        cout << "The number of numbers must be positive!" << endl;
        return 1;
    }

    vector<float> numbers(n);

    // Ввод чисел
    cout << "Enter " << n << " floating point numbers (IEEE 754 format):" << endl;
    for (int i = 0; i < n; ++i) {
        cin >> numbers[i];
    }

    // Вычисление суммы
    float sum = 0.0f;
    for (int i = 0; i < n; ++i) {
        sum += numbers[i];
    }

    cout << "Sum of the entered numbers: " << sum << endl;

    return 0;
}